
/*
 * displaySupport.c
 *
 * Created: 27.03.2024 22:16:39
 *  Author: Vanya
 */ 
#include "displaySupport.h"

uint8_t fake_delay_fn(u8x8_t *u8x8, uint8_t msg, uint8_t arg_int, void *arg_ptr){
	return 0;
}

/*
 * eth_routine.h
 *
 * Created: 18.03.2024 20:55:08
 *  Author: Vanya
 */ 


#ifndef ETH_ROUTINE_H_
#define ETH_ROUTINE_H_



void EthernetInit();
void SocketListener(void);





#endif
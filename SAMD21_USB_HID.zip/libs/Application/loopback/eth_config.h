
/*
 * eth_config.h
 *
 * Created: 18.03.2024 20:57:17
 *  Author: Vanya
 */ 

#ifndef ETH_CONFIG_H_
#define ETH_CONFIG_H_




//wiz_NetInfo netInfo = { .mac  = {0x20, 0xcf, 0xF0, 0x82, 0x76, 0x00}, // Mac address
//.ip   = {192, 168, 1, 99},         // IP address
//.sn   = {255, 255, 255, 0},         // Subnet mask
//.dns =  {8,8,8,8},			  // DNS address (google dns)
//.gw   = {192, 168, 1, 1}, // Gateway address
//.dhcp = NETINFO_STATIC};    //Static IP configuration
//
//
//
//uint16_t socketPort[8] = {80, 23, 8080, 8080, 8080, 8080, 8080, 5000};
//uint8_t rx_tx_buff_sizes[]={2,2,2,2,2,2,2,2};
//












#endif

/*
 * eth_routine.c
 *
 * Created: 18.03.2024 20:55:29
 *  Author: Vanya
 */ 

#include "eth_config.h"

void EthernetInit(){
	
}

void SocketListener(void){

}